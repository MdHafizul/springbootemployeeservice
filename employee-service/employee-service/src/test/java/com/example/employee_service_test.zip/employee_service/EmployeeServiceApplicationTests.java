package com.example.employee_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.employeeservice.EmployeeServiceApplication;

@SpringBootTest(classes = EmployeeServiceApplication.class)

class EmployeeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
